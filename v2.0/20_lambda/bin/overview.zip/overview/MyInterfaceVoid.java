package overview;

@FunctionalInterface
public interface MyInterfaceVoid {
	public void method(int param);
}
package overview;

@FunctionalInterface
public interface MyInterfaceParam {
	public void methodWithParam(int param);
//	public void otherMethodWithParam(int param);
}

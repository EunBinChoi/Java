package generic_wildcard;

public class Student extends Person {

}

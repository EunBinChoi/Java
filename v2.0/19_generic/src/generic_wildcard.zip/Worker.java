package generic_wildcard;

public class Worker extends Person {

}

package generic_wildcard;

public class UnivStudent extends Student {

}

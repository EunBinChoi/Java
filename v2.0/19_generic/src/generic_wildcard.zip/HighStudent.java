package generic_wildcard;

public class HighStudent extends Student {

}

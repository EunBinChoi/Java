package generic_wildcard;

public class Person {

}

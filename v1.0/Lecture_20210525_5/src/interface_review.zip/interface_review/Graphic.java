package interface_review;

// Point Ŭ������ implements
public interface Graphic {
	public void move(int dx, int dy);
	public void printOriginal();
}

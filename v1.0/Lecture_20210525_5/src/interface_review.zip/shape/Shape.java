package shape;

import point.Point;

public abstract class Shape {
	protected Point p;
	
	public Shape() {
		p = new Point();
	}
	
	public Shape(int x, int y) {
		p = new Point(x, y);
	}
	
	public Shape(Point p) {
		this(p.getX(), p.getY());
		
		
//		this.p = new Point();
//		this.p.setX(p.getX());
//		this.p.setY(p.getY());
	}
	
	@Override
	public String toString() {
		return p.toString();
	}
	public Point getPoint() {
		return p;
	}

	public abstract void printInfo();
	public abstract double getArea();
}

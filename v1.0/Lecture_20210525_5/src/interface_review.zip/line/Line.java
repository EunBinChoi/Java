package line;

import point.Point;

public abstract class Line {
	protected Point p;
	
	public Line() {
		p = new Point();
	}
	
	public Line(int x, int y) {
		p = new Point(x, y);
	}
	
	public Line(Point p) {
		this(p.getX(), p.getY());
		
//		this.p = new Point();
//		
//		this.p.setX(p.getX());
//		this.p.setY(p.getY());
	}
	
	public abstract void printInfo();
	
	public Point getPoint() {
		return p;
	}
	
	@Override
	public String toString() {
		return p.toString();
	}
}

package line;

import point.Point;

public class StraightLine extends Line{
	
	public StraightLine() {}
	public StraightLine(int x, int y) {
		super(x, y);
	}
	
	public StraightLine(Point p) {
//		super(p.getX(), p.getY());
		
		this(p.getX(), p.getY());
		
	}
	@Override
	public String toString() {
		return super.toString();
	}
	@Override
	public void printInfo() {
		System.out.println("This is Straight Line");
		
	}
}
